
#jlim
jLim=function(P1,P2,Z1,Z2,X2,corX=cor(X2),rr=sqrt(0.8),BM2B,SM2B){
  BB=X2
  
  k=which(abs(Z1)==max(abs(Z1)))
  if(length(k)>1){
    k=k[1]
  }
  
  zz=Z1
  ww=Z2
  
  ww2=-abs(BM2B/SM2B)
  
  #R1=cor(ref[,k],ref)
  R1=corX[,k]
  
  R1b=which(R1>=rr)
  jiao=0
  jiao2=rep(0,nrow(ww2))
  
  for(i in R1b){
    R2=cor(BB[,i],BB)
    R2b=which(R2<rr)
    ss1=zz[i]^2-zz[k]^2
    ss2=ww[i]^2-max(ww[R2b]^2)
    jiao=jiao+exp(0.5*ss1)*(ss2)
    
    ss2=ww2[,i]^2-apply(as.matrix(ww2[,R2b]^2),1,max)
    jiao2=jiao2+exp(0.5*ss1)*(ss2)
  }
  
  return(mean(jiao2>jiao))
}



