#SMI

SMI=function(BM,SM,N,Bref,mult=30){
  q=length(BM)
  grp=1:q
  n=N

  if(mult>1){
  bdie=matrix(nrow=mult,ncol=q)
  bdie2=matrix(nrow=mult,ncol=q)
  withindie=matrix(0,nrow=q,ncol=q)
  withindie2=matrix(0,nrow=q,ncol=q)
  Bref2=Bref

  for(ii in 1:mult){
    sasa2=sample(1:nrow(Bref2),nrow(Bref2),replace=TRUE)
    if(ii==1){
      sasa2=1:nrow(Bref2)
    }
    Bref2s=Bref2[sasa2,]
    kk2=JointSum(BM,SM,N=n,XX=cov(Bref2s),YY0=diag(1),adj_Y=0)
    bdie2[ii,]=kk2$beta
    if(ii==1){
      withindie2=kk2$cov
    }
  }

  betweendie2=cov(bdie2[-1,])
  vdie2=betweendie2*(1+1/mult)+withindie2
  bb30=as.matrix(bdie2[1,])
  cc30=vdie2
  bb3=as.matrix(bb30[grp])
  cc3=cc30[grp,grp]
  }else{
    kk2=JointSum(BM,SM,N=n,XX=cov(Bref),YY0=diag(1),adj_Y=0)
    bb3=kk2$beta
    cc3=kk2$cov
  }
  ll=t(bb3)%*%ginv(cc3)%*%bb3
  dff=qr(cc3)$rank
  pp=pchisq(ll,df=dff,lower.tail=FALSE)
  return(list(beta=bb3,cov=cc3,chisq=ll,df=dff,pvalue=pp))
}


