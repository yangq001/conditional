#CMC
#CMC(Zb,corX,corY,BBB=1000,thres=1.64,nmodelmax=5,st=1,method="CMC")
#colocMA(Zb,corX,corY,BBB=1000,nmodelmax=5,st=1,thres=1.64)
#colocWP5c(Zb,corX,corY,BBB=1000,theta=0.1)



CMC=function(Zb,corX=diag(ncol(Zb)),corY=diag(nrow(Zb)),BBB=1000,thres=1.64,nmodelmax=5,st=1,method="MA"){
  if(method=="MA"){
    return(colocMA(Zb,corX,corY,BBB,thres,nmodelmax,st))
  }
  if(method=="CMC"){
    return(colocWP5c(Zb,corX,corY,BBB,theta=2*(1-pnorm(thres))))
  }
  if(method=="CB"){
    return(jss(Zb))
  }
}


#FIXED AICc WEIGHTS  ******************
#library(MASS)
#library('mvtnorm')
#MA      ALLOWING different steps
colocMA=function(Zb,corX,corY,BBB=100,thres=1.96,nmodelmax=5,st=1){
  Zc=order(-abs(Zb))   #order from MAX to MIN

  if(max(abs(Zb))<thres | nmodelmax==1){
    nmodel=1
    die=c()
  }else{
    die=c(Zc[1])
    current=1
    po=2
    while(current < nmodelmax*st-1){
      if(abs(Zb[Zc[po]]) < thres){
        current=999
        next
      }
      Zd=Zb*0
      Zd[c(die,Zc[po])]=1
      how=sum(colMeans(Zd)==1)
      if(how > 0){     #cannot add more (otherwise coloc, not null), skip to next
        po=po+1
      }else{      #add more
        current=current+1
        die=c(die,Zc[po])
        po=po+1
      }

      if(po>length(Zc)){   #every Z has been examined
        current=999
      }
    }
  }
  nmodel=floor(length(die)/st)+1

  #MA
  coco=kronecker(corX,corY)  #cov
  ac=c()
  bebe=matrix(nrow=nmodel,ncol=ncol(coco))
  vovo=list()
  detcoco=det(coco)
  ginvcoco=MASS::ginv(coco)
  pdie=c()

  #model 0
  me=0*c(Zb)
  x=c(Zb)
  lnl=-0.5*(log(abs(det(coco)))+t(x-me)%*%MASS::ginv(coco)%*%(x-me)+length(me)*log(2*pi))
  #ac[1]=2*0-2*lnl
  ac[1]=-2-2*lnl
  pdie[1]=colocWPya(Zb,me,corX,corY,BBB=BBB)

  if(nmodel==1){
    #return(c(pdie[1],1,pdie[1]))    #fixed
    return(pdie[1])
  }

  for(j in 1:(nmodel-1)){
    #nonzero means
    hahaha=1:(j*st)
    non=die[hahaha]
    me=0*c(Zb)
    me[non]=c(Zb)[non]
    bebe[j,]=me

    #logLik
    lnl=-0.5*(log(abs(det(coco)))+t(x-me)%*%MASS::ginv(coco)%*%(x-me)+length(me)*log(2*pi))

    #likelihood
    #ac[j+1]=2*j-2*lnl
    ac[j+1]=-2-2*lnl

    #CMC p-value
    pdie[j+1]=colocWPya(Zb,me,corX,corY,BBB=BBB)
  }


  #MA
  aaa=ac
  #aaa=aaa+2*c(0:(nmodel-1))*(2+1)/(length(me)-2-1)  #AICc

  #standardize
  aaa=aaa-min(aaa)
  w1=exp(-aaa/2)
  w2=w1/sum(w1)     #Weights for different models

  ok=which(w2!=0)
  pdie=pdie[ok]
  w2=w2[ok]
  pma=sum(pdie*w2)    #MA p-value

  pma1=sum(w2/pdie)
  pma2=sum(w2)/pma1    #harmonic

  #return(c(pma,nmodel,pma2))
  return(c(pma))
}




#multiple traits, Monte Carlo, rmv, specify nonzero means
colocWPya=function(Zb,me,corX,corY,BBB=100){
  p=nrow(Zb)  #traits
  q=ncol(Zb)  #SNPs

  meme=Zb*0   #mean
  meme[abs(me)>0]=999

  #observed
  fuc=c()
  for(j in 1:q){
    fuc[j]=min(abs(Zb[,j]))
  }
  tt=max(fuc)

  #get cov for Z11,...,Z1q,  Z21,...,Z2q, ...  Zp1,...,Zpq
  cdie=kronecker(corY,corX)

  #calculate prob P(min<tt,min<tt,...,min<tt)
  #tf1=Sys.time()
  simZ=abs(mvtnorm::rmvnorm(BBB,c(t(meme)),cdie))  #correct
  #tf2=Sys.time(); tf2-tf1

  ZV=matrix(nrow=BBB,ncol=q)
  for(j in 1:q){
    india=q*c(1:p)+j-q
    ZV[,j]=apply(simZ[,india],1,min)
  }

  simZT=apply(ZV,1,max)

  return(mean(simZT>tt))

}


#CMC multiple traits, Monte Carlo, rmv  CORRECTED
colocWP5c=function(Zb,corX,corY,BBB=100,theta=0.05){
  cutoff=abs(qnorm(theta/2))
  p=nrow(Zb)  #traits
  q=ncol(Zb)  #SNPs

  meme=Zb*0   #mean       CORRECTED
  for(j in 1:q){
    sj=abs(Zb[,j])
    wsj=which(sj>cutoff)
    meme[wsj,j]=999

    wsj=which(sj==min(sj))[1]
    meme[wsj,j]=0
  }

  #observed
  fuc=c()
  for(j in 1:q){
    fuc[j]=min(abs(Zb[,j]))
  }
  tt=max(fuc)

  #get cov for Z11,...,Z1q,  Z21,...,Z2q, ...  Zp1,...,Zpq
  cdie=kronecker(corY,corX)

  #calculate prob P(min<tt,min<tt,...,min<tt)
  #tf1=Sys.time()
  simZ=abs(mvtnorm::rmvnorm(BBB,c(t(meme)),cdie))  #correct
  #tf2=Sys.time(); tf2-tf1

  ZV=matrix(nrow=BBB,ncol=q)
  for(j in 1:q){
    india=q*c(1:p)+j-q
    ZV[,j]=apply(simZ[,india],1,min)
  }

  simZT=apply(ZV,1,max)

  return(mean(simZT>tt))

}


### CB   take Zb ***
jss=function(Zb){
  pp1=2*pnorm(-abs(t(Zb)))

  pp3=apply(pp1,1,max)
  pp3b=length(pp3)*min(pp3)
  pp3c=sort(pp3)*(length(pp3):1)

  return(min(pp3c[1],1))
}


### CB   take marginal BM SM  *** allow to incorporate SMI
js2=function(BM,SM,ref,N,SMI=0){
  qq=ncol(BM)
  pp=nrow(BM)

  pp1=matrix(nrow=pp,ncol=qq)

  BMM=matrix(nrow=pp,ncol=qq)
  SMM=matrix(nrow=pp,ncol=qq)

  for(i in 1:qq){
    if(SMI==1){
      ll1=SMI(BM[,i],SM[,i],N=N[,i],ref,mult=30)
    }else{
      ll1=JointSum(BM[,i],SM[,i],N=N[,i],XX=cov(ref),YY0=diag(1),adj_Y=0)
    }
    BMM[,i]=ll1$beta
    SMM[,i]=sqrt(diag(ll1$cov))
    #pp1[,i]=ll1$pvalue   NOT FOR SMI!
    pp1[,i]=2*pnorm(-abs(BMM[,i]/SMM[,i]))

  }

  pp3=apply(pp1,1,max)

  pp3b=length(pp3)*min(pp3)

  pp3c=sort(pp3)*(length(pp3):1)

  return(pp3c)
}
